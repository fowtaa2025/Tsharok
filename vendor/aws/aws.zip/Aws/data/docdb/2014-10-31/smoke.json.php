<?php
// This file was auto-generated from sdk-root/src/data/docdb/2014-10-31/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeDBEngineVersions', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeDBInstances', 'input' => [ 'DBInstanceIdentifier' => 'fake-id', ], 'errorExpectedFromService' => true, ], ],];
