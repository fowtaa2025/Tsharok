<?php
// This file was auto-generated from sdk-root/src/data/swf/2012-01-25/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListDomains', 'input' => [ 'registrationStatus' => 'REGISTERED', ], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeDomain', 'input' => [ 'name' => 'fake_domain', ], 'errorExpectedFromService' => true, ], ],];
