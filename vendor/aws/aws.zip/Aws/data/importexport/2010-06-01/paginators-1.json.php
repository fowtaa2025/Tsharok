<?php
// This file was auto-generated from sdk-root/src/data/importexport/2010-06-01/paginators-1.json
return [ 'pagination' => [ 'ListJobs' => [ 'input_token' => 'Marker', 'output_token' => 'Jobs[-1].JobId', 'more_results' => 'IsTruncated', 'limit_key' => 'MaxJobs', 'result_key' => 'Jobs', ], ],];
