<?php
// This file was auto-generated from sdk-root/src/data/eks-auth/2023-11-26/paginators-1.json
return [ 'pagination' => [],];
